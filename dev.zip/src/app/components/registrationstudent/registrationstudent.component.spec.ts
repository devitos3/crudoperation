import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationstudentComponent } from './registrationstudent.component';

describe('RegistrationstudentComponent', () => {
  let component: RegistrationstudentComponent;
  let fixture: ComponentFixture<RegistrationstudentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RegistrationstudentComponent]
    });
    fixture = TestBed.createComponent(RegistrationstudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
