import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginstudentComponent } from './loginstudent.component';

describe('LoginstudentComponent', () => {
  let component: LoginstudentComponent;
  let fixture: ComponentFixture<LoginstudentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LoginstudentComponent]
    });
    fixture = TestBed.createComponent(LoginstudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
